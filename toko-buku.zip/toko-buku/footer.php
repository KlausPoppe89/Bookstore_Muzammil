<div class="container-fluid py-4 bg-footer text-light">
    <div class="container d-flex justify-content-between">
        <label>&copy;2025 Toko Buku</label>
        <label>Created by Muzammil</label>
    </div>
</div>