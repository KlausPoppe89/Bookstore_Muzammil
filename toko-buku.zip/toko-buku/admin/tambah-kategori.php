<?php
require_once '../koneksi.php';
require_admin();

$querykategori = mysqli_query($conn, "SELECT * FROM kategori");
$jumlahkategori = mysqli_num_rows($querykategori);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel || Tambah Kategori</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <?php include "navbar.php"; ?>

    <div class="container mt-5">
        <div class="my-5 col-12 col-md-6"></div>
        <h3>Tambah Kategori</h3>
        <div class="mt-3">
            <form action="" method="post">
                <div class="mb-3">
                    <label for="kategori" class="form-label">Nama Kategori</label>
                    <input type="text" class="form-control" id="kategori" name="kategori" required>
                </div>
                <button class="btn btn-primary" type="submit" name="simpan_kategori">Tambah</button>
            </form>
            <?php
            if (isset($_POST['simpan_kategori'])) {
                $kategori = htmlspecialchars($_POST['kategori']);

                $queryExist = mysqli_query($conn, "SELECT nama FROM kategori WHERE nama = '$kategori'");
                $jumlahDataKategoriBaru = mysqli_num_rows($queryExist);

                if ($jumlahDataKategoriBaru > 0) {
            ?>
                    <div class="alert alert-warning mt-3" role="alert">
                        Kategori sudah ada
                    </div>
                    <?php
                } else {
                    $quesrySimpan = mysqli_query($conn, "INSERT INTO kategori (nama) VALUES ('$kategori')");

                    if ($quesrySimpan) {
                    ?>
                        <div class="alert alert-primary mt-3" role="alert">
                            Kategori berhasil ditambahkan
                        </div>

                        <meta http-equiv="refresh" content="1; url=kategori.php">
            <?php
                    } else {
                        echo mysqli_error($conn);
                    }
                }
            }
            ?>
        </div>
    </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>

</html>