<?php
require_once '../koneksi.php';
?>

<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item me-2">
                    <a class="nav-link" href="../admin">Home</a>
                </li>
                <li class="nav-item me-2">
                    <a class="nav-link" href="kategori.php">Kategori</a>
                </li>
                <li class="nav-item me-2">
                    <a class="nav-link" href="buku.php">Buku</a>
                </li>
                <li class="nav-item me-2">
                    <a class="nav-link" href="user.php">User</a>
                </li>
                <li class="nav-item me-2">
                    <a class="nav-link" href="pesan.php">Pesan</a>
                </li>
                <li class="nav-item me-2">
                    <a class="nav-link" href="pesanan.php">Pesanan</a>
                </li>
            </ul>

            <!-- Menu login / user -->
            <ul class="navbar-nav mb-2 mb-lg-0">
                <?php if (is_admin()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#">
                            👤 <?php echo htmlspecialchars($_SESSION['user']['nama']); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item text-danger" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>