<?php
require_once '../koneksi.php';
require_admin();

// === Handle aksi ubah status ===
if (isset($_POST['aksi']) && $_POST['aksi'] === 'update_status') {
    $id = intval($_POST['id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    mysqli_query($conn, "UPDATE pesanan SET status='$status' WHERE id=$id");
    header("Location: pesanan.php");
    exit;
}

// === Handle hapus pesanan ===
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);

    // Mulai transaksi biar data aman
    mysqli_begin_transaction($conn);

    try {
        // Ambil semua detail pesanan terkait
        $details = mysqli_query($conn, "SELECT buku_id, qty FROM detail_pesanan WHERE pesanan_id = $id");

        // Kembalikan stok buku
        while ($row = mysqli_fetch_assoc($details)) {
            $buku_id = intval($row['buku_id']);
            $qty = intval($row['qty']);
            mysqli_query($conn, "UPDATE buku SET ketersediaan_stok = 'tersedia' WHERE id = $buku_id");
        }

        // Hapus detail pesanan dan pesanan
        mysqli_query($conn, "DELETE FROM detail_pesanan WHERE pesanan_id = $id");
        mysqli_query($conn, "DELETE FROM pesanan WHERE id = $id");

        mysqli_commit($conn);
        $_SESSION['success'] = "Pesanan berhasil dihapus dan stok dikembalikan!";
        header("Location: pesanan.php");
        exit;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "Gagal menghapus pesanan: " . $e->getMessage();
        header("Location: pesanan.php");
        exit;
    }
}

// === Ambil semua pesanan ===
$res = mysqli_query($conn, "
        SELECT p.*, u.nama AS user_nama 
        FROM pesanan p 
        LEFT JOIN users u ON p.user_id = u.id 
        ORDER BY p.created_at DESC
    ");

// === Ambil semua pesanan yang sudah arrived ===
$res_history = mysqli_query($conn, "
        SELECT p.*, u.nama AS user_nama 
        FROM pesanan p 
        LEFT JOIN users u ON p.user_id = u.id 
        WHERE p.status = 'arrived'
        ORDER BY p.created_at DESC
    ");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel || Pesanan</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <?php include "navbar.php"; ?>

    <div class="container container-main mt-4">
        <!-- Notifikasi -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                ✅ <?php echo $_SESSION['success']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                ❌ <?php echo $_SESSION['error']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <!-- ======== DAFTAR PESANAN ======== -->
        <div class="card card-shadow mb-5">
            <div class="card-header bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">📦 Daftar Pesanan</h4>
                    <span class="badge bg-light text-primary fs-6">
                        Total: <?php echo mysqli_num_rows($res); ?> Pesanan
                    </span>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th width="80">ID</th>
                                <th>Customer</th>
                                <th width="150">Total</th>
                                <th width="120">Status</th>
                                <th width="180">Tanggal</th>
                                <th width="280" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($res) === 0): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">
                                        <div class="py-3">
                                            <i class="fas fa-inbox fa-2x mb-3" style="color: #dee2e6;"></i>
                                            <p class="mb-0">Belum ada pesanan</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php while ($r = mysqli_fetch_assoc($res)): ?>
                                    <tr>
                                        <td>
                                            <strong class="text-primary">#<?php echo $r['id']; ?></strong>
                                        </td>
                                        <td>
                                            <div>
                                                <strong><?php echo htmlspecialchars($r['user_nama']); ?></strong>
                                                <?php if ($r['nama_penerima']): ?>
                                                    <br>
                                                    <small class="text-muted">
                                                        Penerima: <?php echo htmlspecialchars($r['nama_penerima']); ?>
                                                    </small>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <strong class="text-success">
                                                Rp <?php echo number_format($r['total'], 0, ',', '.'); ?>
                                            </strong>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?php echo $r['status']; ?>">
                                                <?php echo ucfirst($r['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo date('d M Y H:i', strtotime($r['created_at'])); ?>
                                            </small>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2 justify-content-center">
                                                <!-- Form ubah status -->
                                                <form method="post" class="d-inline">
                                                    <input type="hidden" name="aksi" value="update_status">
                                                    <input type="hidden" name="id" value="<?php echo $r['id']; ?>">
                                                    <select name="status" class="form-select form-select-sm" onchange="this.form.submit()" style="width: 130px;">
                                                        <option value="pending" <?php if ($r['status'] == 'pending') echo 'selected'; ?>>Pending</option>
                                                        <option value="paid" <?php if ($r['status'] == 'paid') echo 'selected'; ?>>Paid</option>
                                                        <option value="delivered" <?php if ($r['status'] == 'delivered') echo 'selected'; ?>>Delivered</option>
                                                        <option value="arrived" <?php if ($r['status'] == 'arrived') echo 'selected'; ?>>Arrived</option>
                                                        <option value="cancelled" <?php if ($r['status'] == 'cancelled') echo 'selected'; ?>>Cancelled</option>
                                                    </select>
                                                </form>

                                                <!-- Tombol hapus -->
                                                <a href="pesanan.php?hapus=<?php echo $r['id']; ?>"
                                                    class="btn btn-sm btn-danger btn-action"
                                                    onclick="return confirm('Yakin ingin menghapus pesanan #<?php echo $r['id']; ?>? Stok buku akan dikembalikan.')">
                                                    🗑️ Hapus
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ======== RIWAYAT PEMBELIAN ======== -->
        <div class="card card-shadow">
            <div class="card-header bg-success text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">📚 Riwayat Pembelian (Arrived)</h4>
                    <span class="badge bg-light text-success fs-6">
                        Total: <?php echo mysqli_num_rows($res_history); ?> Pesanan
                    </span>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th width="80">ID</th>
                                <th>Customer</th>
                                <th width="150">Total</th>
                                <th width="120">Status</th>
                                <th width="180">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($res_history) === 0): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-muted">
                                        <div class="py-3">
                                            <i class="fas fa-history fa-2x mb-3" style="color: #dee2e6;"></i>
                                            <p class="mb-0">Belum ada pesanan yang telah sampai</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php while ($r = mysqli_fetch_assoc($res_history)): ?>
                                    <tr>
                                        <td><strong class="text-success">#<?php echo $r['id']; ?></strong></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($r['user_nama']); ?></strong>
                                            <?php if ($r['nama_penerima']): ?>
                                                <br>
                                                <small class="text-muted">
                                                    Penerima: <?php echo htmlspecialchars($r['nama_penerima']); ?>
                                                </small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong class="text-success">
                                                Rp <?php echo number_format($r['total'], 0, ',', '.'); ?>
                                            </strong>
                                        </td>
                                        <td>
                                            <span class="status-badge status-arrived">
                                                ✅ Arrived
                                            </span>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo date('d M Y H:i', strtotime($r['created_at'])); ?>
                                            </small>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>

</html>