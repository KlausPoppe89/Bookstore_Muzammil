<?php
require_once '../koneksi.php';
require_admin();

$querykategori = mysqli_query($conn, "SELECT * FROM kategori");
$jumlahkategori = mysqli_num_rows($querykategori);

$querybuku = mysqli_query($conn, "SELECT * FROM buku");
$jumlahbuku = mysqli_num_rows($querybuku);

$queryUser = mysqli_query($conn, "SELECT * FROM users");
$jumlahUser = mysqli_num_rows($queryUser);

$queryPesanan = mysqli_query($conn, "SELECT * FROM pesanan");
$jumlahPesanan = mysqli_num_rows($queryPesanan);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel || Toko Buku</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<style>
    .no-decoration {
        text-decoration: none;
        display: block;
    }

    .summary-buku,
    .summary-kategori,
    .summary-user,
    .summary-pesanan {
        border-radius: 12px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        min-height: 140px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        border: none;
    }

    .summary-buku:hover,
    .summary-kategori:hover,
    .summary-user:hover,
    .summary-pesanan:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }

    .summary-buku {
        background-color: #3498db;
    }

    .summary-kategori {
        background-color: #e74c3c;
    }

    .summary-user {
        background-color: #2ecc71;
    }

    .summary-pesanan {
        background-color: #f39c12;
    }

    .summary-buku h4,
    .summary-kategori h4,
    .summary-user h4,
    .summary-pesanan h4 {
        margin-bottom: 10px;
        font-size: 1.1rem;
    }

    .summary-buku h2,
    .summary-kategori h2,
    .summary-user h2,
    .summary-pesanan h2 {
        font-size: 2.2rem;
        font-weight: bold;
        margin: 0;
    }
</style>

<body>
    <?php include "navbar.php"; ?>

    <div class="container mt-4">
        <h3 class="text-center mb-4">Admin Panel</h3>
        <div class="row text-white text-center">
            <div class="col-md-3 mb-3">
                <a href="buku.php" class="no-decoration">
                    <div class="p-3 summary-buku text-white">
                        <h4><i class="fas fa-book"></i> Buku</h4>
                        <h2><?php echo $jumlahbuku; ?></h2>
                    </div>
                </a>
            </div>
            <div class="col-md-3 mb-3">
                <a href="kategori.php" class="no-decoration">
                    <div class="p-3 summary-kategori text-white">
                        <h4><i class="fas fa-list"></i> Kategori</h4>
                        <h2><?php echo $jumlahkategori; ?></h2>
                    </div>
                </a>
            </div>
            <div class="col-md-3 mb-3">
                <a href="user.php" class="no-decoration">
                    <div class="p-3 summary-user text-white">
                        <h4><i class="fas fa-users"></i> User</h4>
                        <h2><?php echo $jumlahUser; ?></h2>
                    </div>
                </a>
            </div>
            <div class="col-md-3 mb-3">
                <a href="pesanan.php" class="no-decoration">
                    <div class="p-3 summary-pesanan text-white">
                        <h4><i class="fas fa-shopping-cart"></i> Pesanan</h4>
                        <h2><?php echo $jumlahPesanan; ?></h2>
                    </div>
                </a>
            </div>
        </div>

        <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../fontawesome/js/all.min.js"></script>
</body>

</html>