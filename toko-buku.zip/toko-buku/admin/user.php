<?php
require_once '../koneksi.php';
require_admin();

// === Hapus User ===
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $admin_id = $_SESSION['user']['id'] ?? 0;

    if ($id == $admin_id) {
        echo "<script>alert('Tidak bisa menghapus akun yang sedang login!');window.location='user.php';</script>";
        exit;
    }

    mysqli_query($conn, "DELETE FROM users WHERE id=$id");
    echo "<script>alert('User berhasil dihapus!');window.location='user.php';</script>";
    exit;
}

$res = mysqli_query($conn, "SELECT * FROM users ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin panel || User</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<style>
    .header-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
    }

    .search-box {
        position: relative;
    }

    .search-box input {
        border-radius: 30px;
        padding-left: 35px;
    }

    .search-box i {
        position: absolute;
        top: 10px;
        left: 12px;
        color: #888;
    }
</style>

<body>
    <?php include "navbar.php"; ?>

    <div class="container mt-5">
        <div class="header-bar">
            <h3><i class="me-2 text-primary"></i>Daftar Pengguna</h3>
            <div class="search-box">
                <input type="text" id="search" class="form-control" placeholder="Cari user...">
            </div>
        </div>
        <table class="table table-hover align-middle" id="userTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Tanggal Daftar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($r = mysqli_fetch_assoc($res)): ?>
                    <tr>
                        <td><?php echo $r['id']; ?></td>
                        <td><?php echo htmlspecialchars($r['nama']); ?></td>
                        <td><?php echo htmlspecialchars($r['email']); ?></td>
                        <td>
                            <span class="badge bg-<?php echo $r['role'] == 'admin' ? 'primary' : 'secondary'; ?>">
                                <?php echo ucfirst($r['role']); ?>
                            </span>
                        </td>
                        <td><?php echo date('d M Y', strtotime($r['created_at'])); ?></td>
                        <td>
                            <?php if (($r['role'] != 'admin') && ($r['id'] != ($_SESSION['user']['id'] ?? 0))): ?>
                                <a href="users.php?hapus=<?php echo $r['id']; ?>"
                                    class="btn btn-sm btn-danger"
                                    onclick="return confirm('Yakin ingin menghapus user ini?')">
                                    <i class="fa fa-trash"></i> Hapus
                                </a>
                            <?php else: ?>
                                <button class="btn btn-sm btn-secondary" disabled>
                                    <i class="fa fa-lock"></i> Admin
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <script>
        // Fitur pencarian realtime
        document.getElementById('search').addEventListener('keyup', function() {
            const value = this.value.toLowerCase();
            document.querySelectorAll('#userTable tbody tr').forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(value) ? '' : 'none';
            });
        });
    </script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>

</html>